package Hands_on;

public class CheckArmstrongNumber {
    public static void main(String args[]) {
        int num = 153;
        int sum = 0, temp = num;
       
        while (num > 0) {
            int digit = num % 10;
            sum = sum + (digit * digit * digit);
            num = num /10;
        }
        if (temp == sum)
            System.out.println("Armstrong number");
        else
            System.out.println("Not an Armstrong number");
    }
}
 
 