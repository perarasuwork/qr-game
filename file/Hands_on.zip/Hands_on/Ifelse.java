package Hands_on;
 
public class Ifelse {
    public static void main(String args[]) {
        int num = 10;
        if(num> 0) {
            System.out.println("Positive number");
        }
        else {
            System.out.println("Negative number");
        }
    }
 
}