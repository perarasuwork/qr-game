package Hands_on;

public class NestedIfelse {
    public static void main(String args[]) {
        int age =20;
        if (age >=18) {
            if (age >=21) {
                System.out.println("Eligible for everything");
            }
            else {
                System.out.println("Eligible to vote");
            }
        }
        else {
                System.out.println("Not eligible");
            }
        }
    }