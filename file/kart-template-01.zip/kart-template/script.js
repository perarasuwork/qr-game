const resources=[
['Onboarding Kit','Getting started','↗','Find your footing with the essentials for your first days at KART.'],
['Knowledge Hub','Learning','▤','Discover domain knowledge, practical guides, and shared expertise.'],
['Tool Hub','Tools','⊞','Find reusable tools that help make everyday work simpler.'],
['GenAI Learning','Learning','✧','Explore generative AI concepts and develop practical skills.'],
['Bootcamp','Learning','⌘','Build confidence through structured learning and hands-on activities.'],
['Innovation','Innovation','☼','Explore ideas, discover solutions, and turn curiosity into progress.'],
['Portfolio Deep Dive','Learning','◇','Get a deeper understanding of portfolios and their connected systems.'],
['Buzz Reels','Learning','▷','Discover bite-sized knowledge for a fresh perspective.'],
['WMS Studio','Tools','▦','Explore warehouse management knowledge and resources.'],
['Transition Process','Getting started','⇄','Navigate the steps and resources supporting a smooth transition.'],
['Gamification','Learning','⚑','Bring a little play to your learning journey.'],
['Virtual ODC','Getting started','▧','Get familiar with your virtual delivery workspace.'],
['Client Visit','Getting started','♧','Explore resources for preparing and supporting client visits.'],
['QEA Scenario Repository','Tools','▱','Find testing scenarios to support your quality engineering work.'],
['Contribute Knowledge','Innovation','＋','Share what you know and help the community grow.']
];
let category='All resources';const search=document.querySelector('#search'),grid=document.querySelector('#resources'),filters=document.querySelector('.filters'),dialog=document.querySelector('#detail');
function render(){const query=search.value.toLowerCase().trim();const matches=resources.filter(r=>(category==='All resources'||r[1]===category)&&`${r[0]} ${r[3]}`.toLowerCase().includes(query));grid.replaceChildren();for(const [name,group,icon,copy] of matches){const card=document.createElement('button');card.className='resource';card.innerHTML=`<span class="resource-top"><span class="resource-icon" aria-hidden="true">${icon}</span><span>${group}</span></span><h3>${name}</h3><p>${copy}</p><span class="open">Explore module <span aria-hidden="true">↗</span></span>`;card.addEventListener('click',()=>showDetail(name));grid.append(card)}document.querySelector('#empty').hidden=matches.length!==0;document.querySelector('#count').textContent=`${matches.length} of ${resources.length} resources`;for(const button of filters.children)button.setAttribute('aria-pressed',String(button.textContent===category))}
function showDetail(name){document.querySelector('#detail-title').textContent=name;document.querySelector('#detail-copy').textContent=resources.find(r=>r[0]===name)?.[3]||'';dialog.showModal()}
for(const label of ['All resources','Getting started','Learning','Tools','Innovation']){const button=document.createElement('button');button.textContent=label;button.addEventListener('click',()=>{category=label;render()});filters.append(button)}
document.querySelectorAll('[data-category]').forEach(a=>a.addEventListener('click',()=>{category=a.dataset.category;search.value='';render()}));document.querySelectorAll('[data-detail]').forEach(b=>b.addEventListener('click',()=>showDetail(b.dataset.detail)));document.querySelectorAll('.close,.close-detail').forEach(b=>b.addEventListener('click',()=>dialog.close()));search.addEventListener('input',render);document.addEventListener('keydown',e=>{if(e.key==='/'&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName)&&!dialog.open){e.preventDefault();search.focus()}});render();
