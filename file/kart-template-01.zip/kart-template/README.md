# KART light & gold template

Open `index.html` in your browser for the workspace, or `login.html` for the sign-in design. No installation or internet connection is needed.

Includes responsive layouts, 15 existing KART module names, working search and category filters, accessible resource dialogs, and a matching sign-in preview. Resource descriptions are proposed copy. Module buttons show preview details; they do not call the running application. Authentication and ARIA are not implemented in this standalone template.

The original application has not been modified. The reference folder located during inspection was `C:\Users\2484123\OneDrive - Cognizant\Documents\PyKart_backup_20260807\prod`. A separate `Documents\prod` folder also exists; confirm which application is active before integration.

## Flask integration

1. Place styles and scripts in the application's static directory and reference them with Flask `url_for`.
2. Adapt the workspace to extend `base.html`. Load module names and endpoints from `config.ui.nav.pages`; use `url_for(item.endpoint)` for real module links instead of preview dialogs.
3. Preserve the existing authentication form actions, input names, validation, CSRF protection, session handling, and sign-up flow when applying the sign-in styling.
4. Keep the existing ARIA widget include and connect configured home content, video, and award data as needed. These are not replaced by this preview.
5. Verify authenticated navigation and mobile layouts on the active application before rollout.

Theme variables are at the top of `styles.css`. The template uses local system fonts and CSS artwork, with no external packages or tracking.
