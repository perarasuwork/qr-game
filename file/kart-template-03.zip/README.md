# KART Template 03 — Nova

This is a standalone animated design preview for KART. Open `index.html` for the landing page and `login.html` for the login page.

The design includes animated gradients, an orbiting knowledge network, floating cards, scroll reveals, number counters, card tilt, search and category filters, resource dialogs, an animated login scene, password visibility control, and a preview login transition. Motion is automatically reduced when the device has “Reduce motion” enabled.

No credentials are sent or stored. The existing Flask application and the first two templates remain unchanged. During Flask integration, preserve the current authentication actions, field names, CSRF/session handling, routes, ARIA widget, and configuration-driven module URLs.
