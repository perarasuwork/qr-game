package Hands_on;

import java.util.Scanner;

public class BasicSyntax {
	public static void main(String args[]) {
		System.out.println("Welcome");
		
		int a = 10;
		System.out.println("Integer value: " + a);
		if (args.length > 0) {
			System.out.println(args[0]);
		}
		Scanner sc = new Scanner(System.in);
		int b = sc.nextInt();
		System.out.println("User Input:" + b);
	}
}




